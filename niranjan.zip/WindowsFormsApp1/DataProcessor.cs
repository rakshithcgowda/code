﻿using System;
using System.Collections.Generic;

namespace WindowsFormsApp1  // Ensure the namespace matches the one in Form1.cs
{
    public class DataProcessor
    {
        private string filePath;

        public DataProcessor(string filePath)
        {
            this.filePath = filePath;
        }

        // Example method for loading and processing data
        public List<dynamic> LoadAndProcessData()
        {
            List<dynamic> data = new List<dynamic>();

            // Logic to read and process data from filePath

            return data;
        }
    }
}
