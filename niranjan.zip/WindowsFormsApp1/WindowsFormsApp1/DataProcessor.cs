﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Dynamic;
using System.Linq;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public class DataProcessor
    {
        private string filePath;

        public DataProcessor(string filePath)
        {
            this.filePath = filePath;
        }

        public List<dynamic> LoadAndProcessData()
        {
            List<dynamic> processedData = new List<dynamic>();

            try
            {
                if (!File.Exists(filePath))
                {
                    throw new FileNotFoundException("Data file not found!");
                }

                var lines = File.ReadAllLines(filePath);

                foreach (var line in lines)
                {
                    if (string.IsNullOrWhiteSpace(line)) continue;

                    var fields = line.Split(',');
                    if (fields.Length < 20) continue;  // Ensure enough columns exist

                    dynamic record = new ExpandoObject();
                    record.Strike = fields[5].Trim();
                    record.CE = fields[15].Trim();
                    record.PE = fields[16].Trim();
                    record.NetQty = Convert.ToInt32(fields[12].Trim());

                    processedData.Add(record);
                }

                // Grouping by Strike and keeping unique entries
                var groupedData = processedData
                    .GroupBy(d => d.Strike)
                    .Select(g => g.First())
                    .ToList();

                return groupedData;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error processing data: {ex.Message}");
                return new List<dynamic>();
            }
        }
    }
}
