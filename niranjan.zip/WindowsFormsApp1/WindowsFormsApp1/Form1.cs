﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private DataProcessor dataProcessor;
        private DataGridView dataGridView;
        private Timer refreshTimer;
        private Label popupMessageLabel;
        private string filePath = @"D:\Lotus\clickme\NIFTY BOX 26.12.2024.txt"; 
        // Ensure this path is valid

        public Form1()
        {
            InitializeComponent();
            dataProcessor = new DataProcessor(filePath);

            // Initialize and set up controls
            dataGridView = new DataGridView { Dock = DockStyle.Top, Height = (int)AutoScaleMode };
            this.Controls.Add(dataGridView);

            popupMessageLabel = new Label
            {
                Dock = DockStyle.Bottom,
                Height = 50,
                Text = "No non-zero values detected.",
                TextAlign = ContentAlignment.MiddleCenter
            };
            this.Controls.Add(popupMessageLabel);

            refreshTimer = new Timer { Interval = 10000 }; // 10 seconds refresh interval
            refreshTimer.Tick += RefreshTimer_Tick;
            refreshTimer.Start();

            LoadData();
        }

        private void LoadData()
        {
            var data = dataProcessor.LoadAndProcessData();
    
            if (data.Count > 0)
            {
                dataGridView.DataSource = data;
            }
            else
            {
                MessageBox.Show("No data available or incorrect format.");
            }

            // Check for non-zero values and show a popup if needed
            CheckForNonZeroValues(data);
        }


        private void CheckForNonZeroValues(List<dynamic> data)
        {
            bool popupTriggered = false;
            foreach (var item in data)
            {
                //if (item.NetQty != 0 && !popupTriggered)
                //{
                //    ShowPopup("Net Row has a non-zero value!");
                //    popupTriggered = true;
                //    break;
                //}
            }
        }

        private void ShowPopup(string message)
        {
            popupMessageLabel.Text = message;
            popupMessageLabel.BackColor = Color.Yellow;
        }

        private void RefreshTimer_Tick(object sender, EventArgs e)
        {
            LoadData();
        }

        // Dispose method for cleanup
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                components?.Dispose(); // No need to redefine 'components'
            }
            base.Dispose(disposing);
        }
    }
}
