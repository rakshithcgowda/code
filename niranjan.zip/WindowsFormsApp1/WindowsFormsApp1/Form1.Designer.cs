﻿using System.Windows.Forms;

namespace WindowsFormsApp1
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dataGridView1;

        // Initialization of components (auto-generated)
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.SuspendLayout();

            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
                new System.Windows.Forms.DataGridViewTextBoxColumn() { Name = "Strike", HeaderText = "Strike" },
                new System.Windows.Forms.DataGridViewTextBoxColumn() { Name = "CE", HeaderText = "CE" },
                new System.Windows.Forms.DataGridViewTextBoxColumn() { Name = "PE", HeaderText = "PE" },
                new System.Windows.Forms.DataGridViewTextBoxColumn() { Name = "Net", HeaderText = "Net" }
            });

            // Centering the content of each column
            foreach (DataGridViewColumn column in this.dataGridView1.Columns)
            {
                column.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }

            // Centering the column headers
            this.dataGridView1.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Setting the appearance and layout for the DataGridView
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;  // Automatically fill the width of the grid
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(760, 400);
            this.dataGridView1.TabIndex = 0;

            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(800, 600);  // Adjusting the size of the form
            this.Controls.Add(this.dataGridView1);  // Adding the DataGridView to the form
            this.Name = "Form1";  // Form name
            this.Text = "Stock Data Viewer";  // Title of the form 
            this.ResumeLayout(false);  // Resume layout
        }
    }
}
